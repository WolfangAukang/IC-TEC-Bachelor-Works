# -*- coding: cp1252 -*-
'''
Created on 11/09/2013
@author: Kevin Alvarado, David Obando, Pedro Rodr�guez
'''
import PrograCode
if __name__ == '__main__':
    pass 
    print PrograCode
    
    
    
    