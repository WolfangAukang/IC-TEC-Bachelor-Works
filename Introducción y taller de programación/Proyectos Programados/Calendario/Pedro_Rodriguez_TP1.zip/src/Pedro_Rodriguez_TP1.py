'''Instituto Tecnologico de Costa Rica
Escuela de Computacion
Ingenieria en Computacion
Introduccion a la programacion
Profesor: Carlos Benavides
Estudiante: Pedro Henrique Rodriguez de Oliveira
Calendario Gregoriano
2013'''
'''Entrada: Un numero del 1 al 4 que indica la opcion en la cual el usuario desea entrar
Salida: Si se inserta el numero uno, se adentrara en la funcion calendariomes.
Si se inserta el numero dos, se adentrara en la funcion calendarioanno.
Si se inserta el numero tres, se adentrara en la funcion bisiesto.
Si se inserta el numero cuatro, se saldra del programa.
Restricciones: Que el numero sea mayor a 4 o menor a 1, saliendo un mensaje de entrada invalida'''
def calendariomenu():
        print "Elija entre las siguientes opciones:"
        print "  1. Generar calendario de un mes"
        print "  2. Generar calendario de un anno"
        print "  3. Consultar si un anno es bisiesto o no"
        print "  4. Salir del programa"
        opcion=input("Cual desea escoger? ")
        if opcion==1:
            return calendariomes()
        if opcion==2:
            return calendariomesanno()
        elif opcion==3:
            return bisiesto()
            print"\n"
        elif opcion==4:
            return "Vas a salir del programa"
        else:
            return "Entrada invalida"
            
'''Entrada: Un numero el cual es el anno indicado por el usuario
Salida: Una frase indicando si el anno insertado es bisiesto o no
Restriccion: El numero no puede ser negativo. Se mostrara mensaje de error'''
def bisiesto():
    anno=input("Favor digite anno: ")
    if anno>=0:
        if anno%4==0 and (anno%100!=0 or anno%400==0):
            return "Anno es bisiesto"
        else:
            return "Anno no es bisiesto"
    else:
        return "Error, el numero no es valido"
    
'''Entrada: Dos numeros, uno que indica el anno y otro que indica el mes, ambos insertados por el usuario
Salida: El calendario del mes del anno, indicado por el usuario.
Restriccion: El mes no puede ser mayor a 12 ni menor a 1, ni el anno puede ser expresado como numero real.
Si se inserta algo respecto a la restriccion, se mostrara mensaje de error'''
def calendariomes():
    anno=input("Favor insertar anno: ")
    mes=input("Favor insertar mes, en numeros: ")
    print anno
    if 0<mes<13 or anno>=0:
        if anno>1582: #Si anno es gregoriano
            if anno%4==0 or anno%400==0 and not anno%100==0:   #Si anno es bisiesto
                if mes==1 or mes==4 or mes==7:            #Si mes es igual a 1, 4 o 7, Algoritmo de Kraitchik lo interpreta como un 6
                    m=6
                elif mes==2 or mes==8:          #Si mes es igual a 2 o 8, Algoritmo de Kraitchik lo interpreta como un 2
                    m=2
                elif mes==3 or mes==11:         #Si mes es igual a 3 o 11, Algoritmo de Kraitchik lo interpreta como un 3
                    m=3
                elif mes==5:          #Si mes es igual a 5, Algoritmo de Kraitchik lo interpreta como un 1
                    m=1
                elif mes==9 or mes==12:         #Si mes es igual a 9 o 12, Algoritmo de Kraitchik lo interpreta como un 5
                    m=5
                elif mes==6:                   #Si mes es igual a 6, Algoritmo de Kraitchik lo interpreta como un 4
                    m=4
                elif mes==10:                 #Si mes es igual a 10, Algoritmo de Kraitchik lo interpreta como un 0
                    m=0
            else:                                        #Si anno no es bisiesto
                if mes==1 or mes==10:            #Si mes es igual a 1 o 10, Algoritmo de Kraitchik lo interpreta como un 0
                    m=0
                elif mes==2 or mes==3 or mes==11:          #Si mes es igual a 2, 3 o 11, Algoritmo de Kraitchik lo interpreta como un 3
                    m=3
                elif mes==4 or mes==7:         #Si mes es igual a 4 o 7, Algoritmo de Kraitchik lo interpreta como un 6
                    m=6
                elif mes==5:          #Si mes es igual a 5, Algoritmo de Kraitchik lo interpreta como un 1
                    m=1
                elif mes==9 or mes==12:         #Si mes es igual a 9 o 12, Algoritmo de Kraitchik lo interpreta como un 5
                    m=5
                elif mes==6:                   #Si mes es igual a 6, Algoritmo de Kraitchik lo interpreta como un 4
                    m=4
                elif mes==8:                 #Si mes es igual a 8, Algoritmo de Kraitchik lo interprete como un 2
                    m=2
            c=(anno/100)%4               #Formula para calcular "c" para anno gregoriano en algoritmo de Kraitchik.
            if c==0:                    #Si formula es igual a 0, c es igual a 5
                c=0
            elif c==1:                  #Si formula es igual a 1, c es igual a 4
                c=5
            elif c==2:                  #Si formula es igual a 2, c es igual a 3
                c=3
            elif c==3:                  #Si formula es igual a 3, c es igual a 2
                c=1
        else:                          #Si ano es juliano
            if mes==1 or mes==5:            #Si mes es igual a 1 o 5, Algoritmo de Kraitchik lo interpreta como un 1
                m=1
            elif mes==2 or mes==6:          #Si mes es igual a 2 o 6, Algoritmo de Kraitchik lo interpreta como un 4
                m=4
            elif mes==3 or mes==11:         #Si mes es igual a 3 o 11, Algoritmo de Kraitchik lo interpreta como un 3
                m=3
            elif mes==4 or mes==7:          #Si mes es igual a 4 o 7, Algoritmo de Kraitchik lo interpreta como un 6
                m=6
            elif mes==9 or mes==12:         #Si mes es igual a 9 o 12, Algoritmo de Kraitchik lo interpreta como un 5
                m=5
            elif mes==8:                    #Si mes es igual a 8, Algoritmo de Kraitchik lo interpreta como un 2
                m=2
            elif mes==10:                   #Si mes es igual a 10, Algoritmo de Kraitchik lo interpreta como un 0
                m=0
            c=(anno/100)%7               #Formula para calcular "c" para anno juliano en Algoritmo de Kraitchik.
            if c==0:                    #Si formula es igual a 0, c es igual a 5
                c=5
            elif c==1:                  #Si formula es igual a 1, c es igual a 4
                c=4
            elif c==2:                  #Si formula es igual a 2, c es igual a 3
                c=3
            elif c==3:                  #Si formula es igual a 3, c es igual a 2
                c=2
            elif c==4:                  #Si formula es igual a 4, c es igual a 1
                c=1
            elif c==5:                  #Si formula es igual a 5, c es igual a 0
                c=0
            elif c==6:                  #Si formula es igual a 6, c ese mantiene igual
                c=6
        dosultimosdigitos=anno%100  #Pra calcular "y" en algoritmo de Kraitchik, se debe aplica la siguiente formula para obtener los dos ultimos digitos del anno
        if dosultimosdigitos in [0, 6, 17, 23, 28, 34, 45, 51, 56, 62, 73, 79, 84, 90]:   #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 0
            y=0
        elif dosultimosdigitos in [1, 7, 12, 18, 29, 35, 40, 46, 57, 63, 68, 74, 85, 91, 96]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 1
            y=1
        elif dosultimosdigitos in [2, 13, 19, 24, 30, 41, 47, 52, 58, 69, 75, 80, 86, 97]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 2
            y=2
        elif dosultimosdigitos in [3, 8, 14, 25, 31, 36, 42, 53, 59, 64, 70, 81, 87, 92, 98]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 3
            y=3
        elif dosultimosdigitos in [9, 15, 20, 26, 37, 43, 48, 54, 65, 71, 76, 82, 93, 99]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 4
            y=4
        elif dosultimosdigitos in [4, 10, 21, 27, 32, 38, 49, 55, 60, 66, 77, 83, 88, 94]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 5
            y=5
        else: #Si los dos ultimos digitos son equivalentes numeros no mencionados anteriormente, y seria igual a 6
            y=6
        d=1 #D es igual a 1 porque nos interesa saber cuando cae el primer dia de cada mes.
        w=(d+m+c+y)%7 #W es igual a la suma de d+m+c+y modulo de 7
        if w==0:
            w==7
        if mes==1:
            print "Enero"
        elif mes==2:
            print "Febrero"
        elif mes==3:
            print "Marzo"
        elif mes==4:
            print "Abril"
        elif mes==5:
            print "Mayo"
        elif mes==6:
            print "Junio"
        elif mes==7:
            print "Julio"
        elif mes==8:
            print "Agosto"
        elif mes==9:
            print "Septiembre"
        elif mes==10:
            print "Octubre"
        elif mes==11:
            print "Noviembre"
        else:
            print "Diciembre"
        if mes in [1,3,5,7,8,10,12]:
            if w==1:
                return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n29 30 31\n"
            elif w==2:
                return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28 29 30 31\n"
            elif w==3:
                return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28 29 30 31\n"
            elif w==4:
                return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28 29 30 31\n"
            elif w==5:
                return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28 29 30 31\n"
            elif w==6:
                return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28 29 30\n31\n"
            elif w==7:
                return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28 29\n30 31\n"
        elif mes in [4,6,9,11]:
            if w==1:
                return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n29 30\n"
            elif w==2:
                return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28 29 30\n"
            elif w==3:
                return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28 29 30\n"
            elif w==4:
                return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28 29 30\n"
            elif w==5:
                return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28 29 30\n"
            elif w==6:
                return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28 29 30\n"
            elif w==7:
                return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28 29\n30\n"
        elif mes==2:
            if anno%4==0 and (anno%100!=0 or anno%400==0):
                if w==1:
                    return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n29\n"
                elif w==2:
                    return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28 29\n"
                elif w==3:
                    return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28 29\n"
                elif w==4:
                    return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28 29\n"
                elif w==5:
                    return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28 29\n"
                elif w==6:
                    return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28 29\n"
                elif w==7:
                    return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28 29\n"
            else:
                if w==1:
                    return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n"
                elif w==2:
                    return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28\n"
                elif w==3:
                    return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28\n"
                elif w==4:
                    return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28\n"
                elif w==5:
                    return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28\n"
                elif w==6:
                    return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28\n"
                elif w==7:
                    return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28\n"
    else:
        return "Error. Los datos brindados estan equivocados \n"
    
'''Entrada: Dos numeros, uno que indica el anno y otro que indica el mes, ambos insertados por el usuario
Salida: El calendario del mes del anno, indicado por el usuario.
Restriccion: Anno no puede ser negativo. Se mostrara mensaje de error'''   
def calendariomesanno(anno, mes, m):
    if 0<mes<13 or anno>=0:
        if anno>1582: #Si anno es gregoriano
            if anno%4==0 or anno%400==0 and not anno%100==0:   #Si anno es bisiesto
                if mes==1 or mes==4 or mes==7:            #Si mes es igual a 1, 4 o 7, Algoritmo de Kraitchik lo interpreta como un 6
                    m=6
                elif mes==2 or mes==8:          #Si mes es igual a 2 o 8, Algoritmo de Kraitchik lo interpreta como un 2
                    m=2
                elif mes==3 or mes==11:         #Si mes es igual a 3 o 11, Algoritmo de Kraitchik lo interpreta como un 3
                    m=3
                elif mes==5:          #Si mes es igual a 5, Algoritmo de Kraitchik lo interpreta como un 1
                    m=1
                elif mes==9 or mes==12:         #Si mes es igual a 9 o 12, Algoritmo de Kraitchik lo interpreta como un 5
                    m=5
                elif mes==6:                   #Si mes es igual a 6, Algoritmo de Kraitchik lo interpreta como un 4
                    m=4
                elif mes==10:                 #Si mes es igual a 10, Algoritmo de Kraitchik lo interpreta como un 0
                    m=0
            else:                                        #Si anno no es bisiesto
                if mes==1 or mes==10:            #Si mes es igual a 1 o 10, Algoritmo de Kraitchik lo interpreta como un 0
                    m=0
                elif mes==2 or mes==3 or mes==11:          #Si mes es igual a 2, 3 o 11, Algoritmo de Kraitchik lo interpreta como un 3
                    m=3
                elif mes==4 or mes==7:         #Si mes es igual a 4 o 7, Algoritmo de Kraitchik lo interpreta como un 6
                    m=6
                elif mes==5:          #Si mes es igual a 5, Algoritmo de Kraitchik lo interpreta como un 1
                    m=1
                elif mes==9 or mes==12:         #Si mes es igual a 9 o 12, Algoritmo de Kraitchik lo interpreta como un 5
                    m=5
                elif mes==6:                   #Si mes es igual a 6, Algoritmo de Kraitchik lo interpreta como un 4
                    m=4
                elif mes==8:                 #Si mes es igual a 8, Algoritmo de Kraitchik lo interprete como un 2
                    m=2
            c=(anno/100)%4               #Formula para calcular "c" para anno gregoriano en algoritmo de Kraitchik.
            if c==0:                    #Si formula es igual a 0, c es igual a 5
                c=0
            elif c==1:                  #Si formula es igual a 1, c es igual a 4
                c=5
            elif c==2:                  #Si formula es igual a 2, c es igual a 3
                c=3
            elif c==3:                  #Si formula es igual a 3, c es igual a 2
                c=1
        else:                          #Si ano es juliano
            if mes==1 or mes==5:            #Si mes es igual a 1 o 5, Algoritmo de Kraitchik lo interpreta como un 1
                m=1
            elif mes==2 or mes==6:          #Si mes es igual a 2 o 6, Algoritmo de Kraitchik lo interpreta como un 4
                m=4
            elif mes==3 or mes==11:         #Si mes es igual a 3 o 11, Algoritmo de Kraitchik lo interpreta como un 3
                m=3
            elif mes==4 or mes==7:          #Si mes es igual a 4 o 7, Algoritmo de Kraitchik lo interpreta como un 6
                m=6
            elif mes==9 or mes==12:         #Si mes es igual a 9 o 12, Algoritmo de Kraitchik lo interpreta como un 5
                m=5
            elif mes==8:                    #Si mes es igual a 8, Algoritmo de Kraitchik lo interpreta como un 2
                m=2
            elif mes==10:                   #Si mes es igual a 10, Algoritmo de Kraitchik lo interpreta como un 0
                m=0
            c=(anno/100)%7               #Formula para calcular "c" para anno juliano en Algoritmo de Kraitchik.
            if c==0:                    #Si formula es igual a 0, c es igual a 5
                c=5
            elif c==1:                  #Si formula es igual a 1, c es igual a 4
                c=4
            elif c==2:                  #Si formula es igual a 2, c es igual a 3
                c=3
            elif c==3:                  #Si formula es igual a 3, c es igual a 2
                c=2
            elif c==4:                  #Si formula es igual a 4, c es igual a 1
                c=1
            elif c==5:                  #Si formula es igual a 5, c es igual a 0
                c=0
            elif c==6:                  #Si formula es igual a 6, c ese mantiene igual
                c=6
        dosultimosdigitos=anno%100  #Pra calcular "y" en algoritmo de Kraitchik, se debe aplica la siguiente formula para obtener los dos ultimos digitos del anno
        if dosultimosdigitos in [0, 6, 17, 23, 28, 34, 45, 51, 56, 62, 73, 79, 84, 90]:   #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 0
            y=0
        elif dosultimosdigitos in [1, 7, 12, 18, 29, 35, 40, 46, 57, 63, 68, 74, 85, 91, 96]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 1
            y=1
        elif dosultimosdigitos in [2, 13, 19, 24, 30, 41, 47, 52, 58, 69, 75, 80, 86, 97]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 2
            y=2
        elif dosultimosdigitos in [3, 8, 14, 25, 31, 36, 42, 53, 59, 64, 70, 81, 87, 92, 98]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 3
            y=3
        elif dosultimosdigitos in [9, 15, 20, 26, 37, 43, 48, 54, 65, 71, 76, 82, 93, 99]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 4
            y=4
        elif dosultimosdigitos in [4, 10, 21, 27, 32, 38, 49, 55, 60, 66, 77, 83, 88, 94]: #Si los dos ultimos digitos son equivalentes a los numeros anteriores, y seria igual a 5
            y=5
        else: #Si los dos ultimos digitos son equivalentes numeros no mencionados anteriormente, y seria igual a 6
            y=6
        d=1 #D es igual a 1 porque nos interesa saber cuando cae el primer dia de cada mes.
        w=(d+m+c+y)%7 #W es igual a la suma de d+m+c+y modulo de 7
        if w==0:
            w=7
        if mes in [1,3,5,7,8,10,12]:
            if w==1:
                return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n29 30 31\n"
            elif w==2:
                return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28 29 30 31\n"
            elif w==3:
                return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28 29 30 31\n"
            elif w==4:
                return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28 29 30 31\n"
            elif w==5:
                return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28 29 30 31\n"
            elif w==6:
                return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28 29 30\n31\n"
            elif w==7:
                return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28 29\n30 31\n"
        elif mes in [4,6,9,11]:
            if w==1:
                return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n29 30\n"
            elif w==2:
                return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28 29 30\n"
            elif w==3:
                return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28 29 30\n"
            elif w==4:
                return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28 29 30\n"
            elif w==5:
                return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28 29 30\n"
            elif w==6:
                return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28 29 30\n"
            elif w==7:
                return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28 29\n30\n"
        elif mes==2:
            if anno%4==0 and (anno%100!=0 or anno%400==0):
                if w==1:
                    return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n29\n"
                elif w==2:
                    return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28 29\n"
                elif w==3:
                    return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28 29\n"
                elif w==4:
                    return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28 29\n"
                elif w==5:
                    return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28 29\n"
                elif w==6:
                    return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28 29\n"
                elif w==7:
                    return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28 29\n"
            else:
                if w==1:
                    return "D  L  K  M  J  V  S\n1  2  3  4  5  6  7\n8  9  10 11 12 13 14\n15 16 17 18 19 20 21\n22 23 24 25 26 27 28\n"
                elif w==2:
                    return "D  L  K  M  J  V  S\n   1  2  3  4  5  6\n7  8  9  10 11 12 13\n14 15 16 17 18 19 20\n21 22 23 24 25 26 27\n28\n"
                elif w==3:
                    return "D  L  K  M  J  V  S\n      1  2  3  4  5\n6  7  8  9  10 11 12\n13 14 15 16 17 18 19\n20 21 22 23 24 25 26\n27 28\n"
                elif w==4:
                    return "D  L  K  M  J  V  S\n         1  2  3  4\n5  6  7  8  9  10 11\n12 13 14 15 16 17 18\n19 20 21 22 23 24 25\n26 27 28\n"
                elif w==5:
                    return "D  L  K  M  J  V  S\n            1  2  3\n4  5  6  7  8  9  10\n11 12 13 14 15 16 17\n18 19 20 21 22 23 24\n25 26 27 28\n"
                elif w==6:
                    return "D  L  K  M  J  V  S\n               1  2\n3  4  5  6  7  8  9\n10 11 12 13 14 15 16\n17 18 19 20 21 22 23\n24 25 26 27 28\n"
                elif w==7:
                    return "D  L  K  M  J  V  S\n                  1\n2  3  4  5  6  7  8\n9  10 11 12 13 14 15\n16 17 18 19 20 21 22\n23 24 25 26 27 28\n"
    else:
        return "Error. Los datos brindados estan equivocados \n"