'''Instituto Tecnologico de Costa Rica
Escuela de Computacion
Ingenieria en Computacion
Introduccion a la programacion
Profesor: Carlos Benavides
Estudiante: Pedro Henrique Rodriguez de Oliveira
Calendario Gregoriano
2013
'''
'''Notas: He incluido la funcion calendariomenu() directamente al main por motivos del uso del while.
Si el usuario escoge una opcion que sea la 1, 2 o 3 o cualquier numero que no sea 4, el programa brinda la respuesta (en caso de las opciones)
o muestra el mensaje de entrada invalida (cualquiero otro numero mayor a 4 y menor a 1, sin incluir el 4) y vuelve a preguntar otra vez por la opcion
que desea utilizar, aplicandose el while.
Sin embargo, si se inserta el numero 4, ira directo a la pregunta de salir del programa. Si se digita cualquier numero excepto 1, se devuelve a calendariomenu() aplicandose otra vez
un while.
Si se inserta el numero uno, el programa se termina.
Las especificaciones de entrada, salida y restriccion de la funcion calendariomenu() se encuentran dentro del modulo Pedro_Rodriguez_TP1'''
import Pedro_Rodriguez_TP1
if __name__ == '__main__':
    pass
    salir=0
    opcion=0
    print "Bienvenido al calendario"
    while salir!=1:
        while opcion!=4:
            print "Elija entre las siguientes opciones:"
            print "  1. Generar calendario de un mes"
            print "  2. Generar calendario de un anno"
            print "  3. Consultar si un anno es bisiesto o no"
            print "  4. Salir del programa"
            opcion=input("Cual desea escoger? ")
            if opcion==1:
                a=Pedro_Rodriguez_TP1.calendariomes()
                print a
            elif opcion==2:
                anno=input("Favor insertar anno deseado: ")
                print anno
                print "Enero"
                if anno%4==0 and (anno%100!=0 or anno%400==0):
                    a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 1, 6)
                    print a
                else:
                    a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 1, 1)
                    print a
                print "Febrero"
                if anno%4==0 and (anno%100!=0 or anno%400==0):
                    a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 2, 2)
                    print a
                else:
                    a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 2, 4)
                    print a
                print "Marzo"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 3, 3)
                print a
                print "Abril"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 4, 6)
                print a
                print "Mayo"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 5, 1)
                print a
                print "Junio"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 6, 4)
                print a
                print "Julio"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 7, 6)
                print a
                print "Agosto"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 8, 2)
                print a
                print "Septiembre"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 9, 5)
                print a
                print "Octubre"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 10, 0)
                print a
                print "Noviembre"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 11, 3)
                print a
                print "Diciembre"
                a=Pedro_Rodriguez_TP1.calendariomesanno(anno, 12, 5)
                print a
            elif opcion==3:
                a=Pedro_Rodriguez_TP1.bisiesto()
                print a +"\n"
            elif opcion==4:
                print "Vas a salir del programa"
            else:
                print "Entrada invalida\n"
        salir=input("Deseas salir? (1 para si, o cualquier numero para no): ")
        print "\n"
        if salir!=1:
            opcion=0